echo "
                      .   *        .       .
       *      -0-
          .                .  *       - )-
       .      *       o       .       *
 o                |
           .     -O-
.                 |        *      .     -0-
       *  o     .    '       *      .        o
              .         .        |      *
   *             *              -O-          .
         .             *         |     ,
                .           o
        .---.
      _/__~Y_\_     .  *            o       '
     (_________)             .
                 .                        *
       *               - ) -       *
"

sleep 1
echo "UFONET MOBILE VERSION V1 INSTALLING.."
sleep 2
cd core
sh start.sh